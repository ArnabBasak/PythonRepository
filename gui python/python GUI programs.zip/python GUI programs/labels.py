from tkinter import *
root = Tk()
w = Label(root,text = "Hello World")
w.pack()
root.mainloop()

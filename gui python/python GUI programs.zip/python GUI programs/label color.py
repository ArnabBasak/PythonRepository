from tkinter import *
root = Tk()
Label(root,text = "This text in Times new roman",fg = "red",font = "Times").pack()
Label(root,text = "This text is in Helvetica Font",fg = "green",font = "Helvitica 16 bold italic").pack()
Label(root,text = "This text is in Algerian Font",fg = "blue",font = "Algerian 22").pack()
root.mainloop()
